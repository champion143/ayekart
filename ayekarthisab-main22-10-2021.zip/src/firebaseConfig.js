var firebaseConfig = {
  // apiKey: "AIzaSyAKlBsoA_pUp4jVFc8PWRL4-THXKrHKC6g",
  // authDomain: "ayekarthisabsurya.firebaseapp.com",
  // projectId: "ayekarthisabsurya",
  // storageBucket: "ayekarthisabsurya.appspot.com",
  // messagingSenderId: "902570831841",
  // appId: "1:902570831841:web:25121315761abe23276ca0",
  // measurementId: "G-CS8RG4PV72",

  apiKey: "AIzaSyD1mF4hFNv7M8U406_i1eYsGD3BjhzbvNI",
  authDomain: "ayekarthisab.firebaseapp.com",
  databaseURL: "https://ayekarthisab-default-rtdb.firebaseio.com",
  projectId: "ayekarthisab",
  storageBucket: "ayekarthisab.appspot.com",
  messagingSenderId: "815969440683",
  appId: "1:815969440683:web:d5b0729a2bde5d004678ee",
  measurementId: "G-KVG32FXC3V",
};

export default firebaseConfig;
