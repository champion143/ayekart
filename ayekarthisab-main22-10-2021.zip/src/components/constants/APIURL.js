// export const APIURL = "https://proxycorsserversurya.herokuapp.com/https://api.ayekart.com/v1";

// export const APIURL = "https://proxycorsserversurya.herokuapp.com/https://api.ayekart.com/v1";

export const APIURL = "https://api.ayekart.com/v1";

export const APIURLNEW = "http://139.59.91.183/ayekart/api";
